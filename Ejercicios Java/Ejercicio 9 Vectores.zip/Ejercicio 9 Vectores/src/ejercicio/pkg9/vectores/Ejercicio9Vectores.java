package ejercicio.pkg9.vectores;

import java.util.Scanner;

public class Ejercicio9Vectores {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int cont1 = 0;
        int cont2 = 0;
        int cont3 = 0;
        int cont4 = 0;
        System.out.println("Dime un numero");
        int nlength = sc.nextInt();
        int[] vector = new int[nlength];
        for (int i = 0; i < nlength; i++) {
            vector[i] = sc.nextInt();
        }
        int may = vector[0];
        int min = vector[0];
        for (int i = 1; i < nlength; i++) {
            if (vector[i] > may) {
                may = vector[i];
            }
            if (vector[i] < min) {
                min = vector[i];
            }
        }
        for (int i = 0; i < nlength; i++) {
            if (vector[i] > 20) {
                cont1++;
            }
            if (vector[i] <= 20 && vector[i] >= 17) {
                cont2++;
            }
            if (vector[i] <= 16 && vector[i] >= 13) {
                cont3++;
            }
            if (vector[i] <= 12) {
                cont4++;
            }
        }
        System.out.println("El menor es: " + min + "\n" + "El mayor es: " + may + "\n" + "Los mayores a 20 son: " + cont1 + "\n" + "Los que tienen entre 17 y 20 son: " + cont2 + "\n" + "Los que tienen entre 13 y 16 son: " + cont3 + "\n" + "Los menores a 12 son: " + cont4);
    }

}

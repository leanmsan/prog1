package ejercicio.deudores;

import java.util.Scanner;

public class EjercicioDeudores {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el Dni del deudor");
        int dni = sc.nextInt();
        System.out.println("Ingrese el apellido del deudor");
        String apellido = sc.next();
        System.out.println("Ingrese el nombre del deudor");
        String nombre = sc.next();
        System.out.println("Ingrese el Dni del Cotitular");
        int dniCotitular = sc.nextInt();
        System.out.println("Ingrese el apellido del Cotitular");
        String apellidoCotitular = sc.next();
        System.out.println("Ingrese el nombre del Cotitular");
        String nombreCotitular = sc.next();
        System.out.println("Ingrese el monto de la deuda");
        double montoAdeudado = sc.nextDouble();
        System.out.println("Ingrese el año de la deuda");
        int añoDeuda = sc.nextInt();
        Deudor deudor1 = new Deudor(dni, apellido, nombre, dniCotitular, apellidoCotitular, nombreCotitular, montoAdeudado, añoDeuda);
        int opcion = 0;
        do {
            System.out.println("Seleccione una opcion" + "\n" + "1- Ver detalles del Deudor" + "\n" + "2- Ver detalles del Cotitular" + "\n" + "3- Ver detalles de la deuda" + "\n" + "4- Calcular la deuda a la fecha" + "\n" + "5- Realizar plan de pagos" + "\n" + "6- Realizar cambio de Cotitular" + "\n" + "7- Salir");
            opcion = sc.nextInt();
            switch (opcion) {
                case 1:
                    System.out.println("Detalles del Deudor");
                    System.out.println(deudor1.toStringDeudor());
                    break;
                case 2:
                    System.out.println("Detalles del Cotitular");
                    System.out.println(deudor1.toStringCoDeudor());
                    break;
                case 3:
                    System.out.println("Detalles de la Deuda:");
                    System.out.println(deudor1.toString());
                    break;
                case 4:
                    System.out.println("La deuda a la fecha asciende a: " + deudor1.calcularDeudaActual());
                    break;
                case 5:
                    System.out.println("Ingrese la cantidad de cuotas");
                    int cuotas = sc.nextInt();
                    if (cuotas <= 12 && cuotas > 0) {
                        System.out.println("En " + cuotas + " cuotas, el monto de las cuotas asciende a: " + deudor1.calcularPlanDePagos(cuotas));
                    } else {
                        System.out.println("Solo se puede realizar el plan de pagos entre 1 cuota y 12 cuotas");
                    }
                    break;
                case 6:
                    System.out.println("Ingrese el Dni del nuevo Cotitular");
                    int nuevoDniCot = sc.nextInt();
                    System.out.println("Ingrese el Apellido del nuevo Cotitular");
                    String nuevoApCot = sc.next();
                    System.out.println("Ingrese el Nombre del nuevo Cotitular");
                    String nuevoNcot = sc.next();
                    deudor1.CambiarCotitular(nuevoDniCot, nuevoApCot, nuevoNcot);
                    System.out.println("Detalles del nuevo Cotitular");
                    System.out.println(deudor1.toStringCoDeudor());
                    break;
                default:
                    System.out.println("Opcion Incorrecta");
                    break;
            }
        } while (opcion != 7);

        if (opcion == 7) {
            System.out.println("Gracias");
        }
    }
}

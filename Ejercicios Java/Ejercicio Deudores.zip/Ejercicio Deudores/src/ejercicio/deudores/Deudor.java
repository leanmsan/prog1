package ejercicio.deudores;

public class Deudor {

    private String Apellido, Nombre, ApellidoCotitular, NombreCotitular;
    private int añoDeuda, Dni, DniCotitular;
    private double MontoAdeudado;

    public Deudor() {
        this.Dni = 0;
        this.Apellido = "";
        this.Nombre = "";
        this.DniCotitular = 0;
        this.ApellidoCotitular = "";
        this.NombreCotitular = "";
        this.MontoAdeudado = 0;
        this.añoDeuda = 0;
    }

    public Deudor(int Dni, String Apellido, String Nombre, int DniCotitular, String ApellidoCotitular,
            String NombreCotitular, double MontoAdeudado, int añoDeuda) {
        this.Dni = Dni;
        this.Apellido = Apellido;
        this.Nombre = Nombre;
        this.DniCotitular = DniCotitular;
        this.ApellidoCotitular = ApellidoCotitular;
        this.NombreCotitular = NombreCotitular;
        this.MontoAdeudado = MontoAdeudado;
        this.añoDeuda = añoDeuda;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String apellido) {
        Apellido = apellido;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getApellidoCotitular() {
        return ApellidoCotitular;
    }

    public void setApellidoCotitular(String apellidoCotitular) {
        ApellidoCotitular = apellidoCotitular;
    }

    public String getNombreCotitular() {
        return NombreCotitular;
    }

    public void setNombreCotitular(String nombreCotitular) {
        NombreCotitular = nombreCotitular;
    }

    public int getAñoDeuda() {
        return añoDeuda;
    }

    public void setAñoDeuda(int añoDeuda) {
        this.añoDeuda = añoDeuda;
    }

    public int getDni() {
        return Dni;
    }

    public void setDni(int dni) {
        Dni = dni;
    }

    public int getDniCotitular() {
        return DniCotitular;
    }

    public void setDniCotitular(int dniCotitular) {
        DniCotitular = dniCotitular;
    }

    public double getMontoAdeudado() {
        return MontoAdeudado;
    }

    public void setMontoAdeudado(double montoAdeudado) {
        MontoAdeudado = montoAdeudado;
    }

    public double calcularDeudaActual() {
        int años = 2022 - añoDeuda;
        double deudaActual = ((MontoAdeudado * (años * 21) / 100) + MontoAdeudado);
        return deudaActual;
    }

    public double calcularPlanDePagos(int ncuotas) {
        double deudaActual = calcularDeudaActual();
        double cuotas = 0;
        if (ncuotas < 3) {
            cuotas = deudaActual / ncuotas;
        }
        if (ncuotas <= 6 && ncuotas >= 4) {
            cuotas = (deudaActual * 1.10) / ncuotas;
        }
        if (ncuotas <= 12 && ncuotas >= 7) {
            cuotas = (deudaActual * 1.19) / ncuotas;
        }
        return cuotas;
    }

    public void CambiarCotitular(int DniCotitular, String ApellidoCotitular, String NombreCotitular) {
        this.MontoAdeudado = MontoAdeudado * 1.05;
        this.DniCotitular = DniCotitular;
        this.ApellidoCotitular = ApellidoCotitular;
        this.NombreCotitular = NombreCotitular;
    }

    public String toStringDeudor() {
        return "Apellido del Deudor: " + Apellido + ", Nombre del Deudor: " + Nombre + ", Dni del Deudor: " + Dni;
    }

    public String toStringCoDeudor() {
        return "Apellido del Cotitular: " + ApellidoCotitular + ", Nombre del Cotitular: " + NombreCotitular
                + ", Dni del Cotitular: " + DniCotitular;
    }

    public String toString() {
        return "Apellido del Deudor Apellido: \n" + Apellido + ", Nombre del Deudor: \n" + Nombre + ", Dni del Deudor: " + Dni + ", Apellido del Cotitular: "
                + ApellidoCotitular + ", Nombre del Cotitular: " + NombreCotitular + ", Dni Del Cotitular: " + DniCotitular
                + ", Año de la deuda: " + añoDeuda + ", Monto Adeudado: $" + MontoAdeudado;
    }
}

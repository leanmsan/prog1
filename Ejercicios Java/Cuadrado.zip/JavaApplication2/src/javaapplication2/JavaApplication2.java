/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication2;

import java.util.Scanner;

/**
 *
 * @author david.cheein
 */
public class JavaApplication2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc =new Scanner(System.in);
        System.out.println("Ingrese la longitud del lado");
        Cuadrado cuadrado1 =new Cuadrado(sc.nextInt());
        System.out.println("El area es "+cuadrado1.calcularArea());
        System.out.println("El perimetro es "+cuadrado1.calcularPerimetro());
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication2;

public class Cuadrado {
    private float lado;
    public Cuadrado(){
        lado=0;
    }
    public Cuadrado(float lado){
        this.lado=lado;
    }

    /**
     * @return the lado
     */
    public float getLado() {
        return lado;
    }

    /**
     * @param lado the lado to set
     */
    public void setLado(float lado) {
        this.lado = lado;
    }
    
    public float calcularArea(){
        return lado*lado;
    }
    
    public float calcularPerimetro(){
        return lado*4;
    }
}

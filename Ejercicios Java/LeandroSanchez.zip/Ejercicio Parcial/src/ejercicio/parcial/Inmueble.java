package ejercicio.parcial;

public class Inmueble {

    private String Descripcion, Gama;
    private int Codigo;
    private double MetrosCuadrados;

    public Inmueble() {
        this.Codigo = 0;
        this.Descripcion = "";
        this.MetrosCuadrados = 0;
        this.Gama = "";
    }

    public Inmueble(int Codigo, String Descripcion, double MetrosCuadrados, String Gama) {
        this.Codigo = Codigo;
        this.Descripcion = Descripcion;
        this.MetrosCuadrados = MetrosCuadrados;
        this.Gama = Gama;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

    public String getGama() {
        return Gama;
    }

    public void setGama(String Gama) {
        this.Gama = Gama;
    }

    public int getCodigo() {
        return Codigo;
    }

    public void setCodigo(int Codigo) {
        this.Codigo = Codigo;
    }

    public double getMetrosCuadrados() {
        return MetrosCuadrados;
    }

    public void setMetrosCuadrados(double MetrosCuadrados) {
        this.MetrosCuadrados = MetrosCuadrados;
    }

    public String DatosInmueble() {
        return "Codigo: " + Codigo + "Descripcion: " + Descripcion + "\n" + "Gama: " + Gama + ". MetrosCuadrados: " + MetrosCuadrados;
    }

    public double CalcularPrecioVenta() {
        double PrecioVenta = 0;
        if (Gama.equals("Alta")) { //1= Gama alta, 2= gama media, 3= gama baja
            PrecioVenta = 10000 * MetrosCuadrados;
        }
        if (Gama.equals("Media")) {
            PrecioVenta = 7000 * MetrosCuadrados;
        }
        if (Gama.equals("Baja")) {
            PrecioVenta = 4000 * MetrosCuadrados;
        }
        return PrecioVenta;
    }

    public double CalcularPrecioAlquiler(int Meses) {
        double PrecioAlquiler = 0;
        if (Meses < 12 && Meses > 0) {
            if (Gama.equals("Alta")) {
                PrecioAlquiler = (1000 * MetrosCuadrados);
            }
            if (Gama.equals("Media")) {
                PrecioAlquiler = (700 * MetrosCuadrados);
            }
            if (Gama.equals("Baja")) {
                PrecioAlquiler = (400 * MetrosCuadrados);
            }
        }
        if (Meses < 24 && Meses >= 12) {
            if (Gama.equals("Alta")) {
                PrecioAlquiler = (1000 * MetrosCuadrados) * 0.90;
            }
            if (Gama.equals("Media")) {
                PrecioAlquiler = (700 * MetrosCuadrados) * 0.90;
            }
            if (Gama.equals("Baja")) {
                PrecioAlquiler = (400 * MetrosCuadrados) * 0.90;
            }
        }
        if (Meses >= 24) {
            if (Gama.equals("Alta")) {
                PrecioAlquiler = (1000 * MetrosCuadrados) * 0.85;
            }
            if (Gama.equals("Media")) {
                PrecioAlquiler = (700 * MetrosCuadrados) * 0.85;
            }
            if (Gama.equals("Baja")) {
                PrecioAlquiler = (400 * MetrosCuadrados) * 0.85;
            }
        }
        return PrecioAlquiler;
    }

    public double CalcularPrecioReserva(boolean Dolar) {
        double PrecioReserva = 0;
        if (Dolar == true) {
            if (Gama.equals("Alta")) {
                PrecioReserva = (MetrosCuadrados * 100) / 240;
            }
            if (Gama.equals("Media")) {
                PrecioReserva = (MetrosCuadrados * 70) / 240;
            }
            if (Gama.equals("Baja")) {
                PrecioReserva = (MetrosCuadrados * 40) / 240;
            }
        } else {
            if (Gama.equals("Alta")) {
                PrecioReserva = MetrosCuadrados * 100;
            }
            if (Gama.equals("Media")) {
                PrecioReserva = MetrosCuadrados * 70;
            }
            if (Gama.equals("Baja")) {
                PrecioReserva = MetrosCuadrados * 40;
            }
        }
        return PrecioReserva;
    }
}

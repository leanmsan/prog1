package ejercicio.parcial;

import java.util.Scanner;

public class EjercicioParcial {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el codigo del inmueble");
        int codigo = sc.nextInt();
        System.out.println("Ingrese la descripcion del inmueble");
        String descripcion = sc.next();
        System.out.println("Ingrese los metros cuadrados del inmueble");
        double metrosCuadrados = sc.nextDouble();
        System.out.println("Seleccione la gama del inmueble" + "\n" + "1- Alta" + "\n" + "2- Media" + "\n" + "3- Baja");
        int opGama = sc.nextInt();
        String gama = "";
        if (opGama == 1) {
            gama = "Alta";
        }
        if (opGama == 2) {
            gama = "Media";
        }
        if (opGama == 3) {
            gama = "Baja";
        }

        Inmueble inmueble1 = new Inmueble(codigo, descripcion, metrosCuadrados, gama);

        int opcion = 0;
        do {
            System.out.println("Seleccione una opcion" + "\n" + "1- Ver los datos del inmueble" + "\n" + "2- Calcular el precio de venta" + "\n" + "3- Calcular el precio de alquiler" + "\n" + "4- Calcular el precio de reserva" + "\n" + "5- Salir");
            opcion = sc.nextInt();
            switch (opcion) {
                case 1:
                    System.out.println(inmueble1.DatosInmueble());
                    break;
                case 2:
                    System.out.println("El precio de venta del inmueble asciende a: " + inmueble1.CalcularPrecioVenta());
                    break;
                case 3:
                    System.out.println("Ingrese la cantidad de meses a alquilar");
                    int meses = sc.nextInt();
                    System.out.println("El precio del alquiler por mes asciende a: " + inmueble1.CalcularPrecioAlquiler(meses));
                    break;
                case 4:
                    System.out.println("Seleccione la moneda en la que desea hacer la reserva" + "\n" + "1- Dolar" + "\n" + "2- Pesos");
                    int opReserva = sc.nextInt();
                    boolean dolar = false;
                    if (opReserva == 1) {
                        dolar = true;
                        System.out.println("El precio de reserva, en dolares, asciende a: " + inmueble1.CalcularPrecioReserva(dolar));
                    }
                    if (opReserva == 2) {
                        dolar = false;
                        System.out.println("El precio de reserva, en pesos, asciende a: " + inmueble1.CalcularPrecioReserva(dolar));
                    }
                    break;

            }
        } while (opcion != 5);

        if (opcion == 5) {
            System.out.println("Gracias");
        }
    }

}

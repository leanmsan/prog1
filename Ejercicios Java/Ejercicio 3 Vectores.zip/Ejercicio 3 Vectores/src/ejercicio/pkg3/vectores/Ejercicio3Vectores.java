package ejercicio.pkg3.vectores;

import java.util.Scanner;

public class Ejercicio3Vectores {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Dime un numero");
        int nlength = sc.nextInt();
        int[] vector = new int[nlength];
        int suma = 0;
        for (int i = 0; i < nlength; i++) {
            vector[i] = sc.nextInt();
            suma = suma + vector[i];
        }
        int prom = suma / nlength;
        for (int i = 0; i < nlength; i++) {
            if (vector[i] > prom) {
                System.out.println("El numero mayor al promedio es: " + vector[i]);
            }
        }
    }
}

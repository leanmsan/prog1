package ejercicio.pkg5.vectores;

import java.util.Scanner;

public class Ejercicio5Vectores {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Dime un numero");
        int nlength = sc.nextInt();
        int[] vector = new int[nlength];
        for (int i = 0; i < nlength; i++) {
            vector[i] = sc.nextInt();
        }
        int i = 0;
        while (i < nlength) {
            System.out.println("En el indice " + i + ", está el numero " + vector[i]);
            i = i + 2;
        }
    }

}
